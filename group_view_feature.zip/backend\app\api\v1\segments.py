"""
Segment API Routes
===================

CRUD operations for segments, audience estimation, preview,
query compilation, and the attribute catalog.
"""

from __future__ import annotations

import re

from fastapi import APIRouter, HTTPException, Query

from app.schemas.api_schemas import (
    AttributeCatalogResponse,
    AttributeResponse,
    AudienceEstimateRequest,
    AudienceEstimateResponse,
    AudiencePreviewRequest,
    AudiencePreviewResponse,
    AudienceSummaryRequest,
    AudienceSummaryResponse,
    CompileRequest,
    CompileResponse,
    RankSplitRequest,
    RankSplitSaveRequest,
    SavedSegment,
    SavedSegmentCreate,
    SavedSegmentListResponse,
    SavedSegmentUpdate,
    SegmentCreate,
    SegmentListResponse,
    SegmentResponse,
    SegmentUpdate,
)
from app.schemas.profile_attributes import (
    ATTRIBUTE_CATALOG,
    ATTRIBUTES_BY_CATEGORY,
    AttributeCategory,
    get_attributes_for_brand,
)
from app.services.segmentation.service import SegmentationService

router = APIRouter(prefix="/segments", tags=["Segments"])

# Service instance — in production, injected via FastAPI Depends
service = SegmentationService()
PREFIX_SEARCH_MIN_DIGITS = 8
PREFIX_SEARCH_MAX_LIMIT = 50


# =============================================================================
# SEGMENT CRUD
# =============================================================================


@router.post("/", response_model=SegmentResponse)
async def create_segment(payload: SegmentCreate):
    """Create a new segment definition."""
    result = await service.create_segment(
        brand_id=payload.brand_id,
        name=payload.name,
        description=payload.description,
        rules=payload.rules,
        segment_type=payload.segment_type,
        schedule=payload.schedule,
        is_cross_brand=payload.is_cross_brand,
        tags=payload.tags,
    )
    return result


@router.get("/", response_model=SegmentListResponse)
async def list_segments(
    brand_id: str | None = Query(None, description="Filter by brand ID"),
    segment_type: str | None = Query(None, description="Filter by type"),
    is_active: bool | None = Query(None),
    search: str | None = Query(None, description="Search by name"),
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
):
    """List segments with filters and pagination."""
    # In production: query DB with filters
    return SegmentListResponse(segments=[], total=0, page=page, page_size=page_size)


@router.get("/{segment_id}", response_model=SegmentResponse)
async def get_segment(segment_id: str):
    """Get a specific segment by ID."""
    # In production: fetch from DB
    raise HTTPException(status_code=404, detail="Segment not found")


@router.put("/{segment_id}", response_model=SegmentResponse)
async def update_segment(segment_id: str, payload: SegmentUpdate):
    """Update a segment."""
    if payload.rules:
        result = await service.update_segment_rules(segment_id, payload.rules)
    # In production: update other fields in DB
    raise HTTPException(status_code=404, detail="Segment not found")


@router.delete("/{segment_id}")
async def delete_segment(segment_id: str):
    """Delete (soft) a segment."""
    result = await service.delete_segment(segment_id)
    return result


# =============================================================================
# SAVED SEGMENTS REPOSITORY
# =============================================================================


@router.post("/saved", response_model=SavedSegment)
async def create_saved_segment(payload: SavedSegmentCreate):
    """Persist a segment into the Saved Segments repository."""
    return await service.save_segment(payload.model_dump())


@router.get("/saved/list", response_model=SavedSegmentListResponse)
async def list_saved_segments(
    search: str | None = Query(None),
    segment_type: str | None = Query(None, description="customer | corporate | all"),
    status: str | None = Query("active", description="active | archived | all"),
    created_by: str | None = Query(None),
    sort: str = Query("updated", description="updated | created | name | count"),
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=1, le=200),
):
    """List saved segments with search, filters, sort, and pagination."""
    return await service.list_saved_segments(
        search=search, segment_type=segment_type, status=status,
        created_by=created_by, sort=sort, page=page, page_size=page_size,
    )


@router.get("/saved/{seg_id}", response_model=SavedSegment)
async def get_saved_segment(seg_id: str):
    seg = await service.get_saved_segment(seg_id)
    if not seg:
        raise HTTPException(status_code=404, detail="Saved segment not found")
    return seg


@router.put("/saved/{seg_id}", response_model=SavedSegment)
async def update_saved_segment(seg_id: str, payload: SavedSegmentUpdate):
    seg = await service.update_saved_segment(seg_id, payload.model_dump(exclude_unset=True))
    if not seg:
        raise HTTPException(status_code=404, detail="Saved segment not found")
    return seg


@router.post("/saved/{seg_id}/clone", response_model=SavedSegment)
async def clone_saved_segment(seg_id: str, created_by: str | None = Query(None)):
    seg = await service.clone_saved_segment(seg_id, created_by=created_by)
    if not seg:
        raise HTTPException(status_code=404, detail="Saved segment not found")
    return seg


@router.post("/saved/{seg_id}/refresh", response_model=SavedSegment)
async def refresh_saved_segment(seg_id: str):
    seg = await service.refresh_saved_segment_count(seg_id)
    if not seg:
        raise HTTPException(status_code=404, detail="Saved segment not found")
    return seg


@router.delete("/saved/{seg_id}")
async def delete_saved_segment(seg_id: str):
    ok = await service.delete_saved_segment(seg_id)
    if not ok:
        raise HTTPException(status_code=404, detail="Saved segment not found")
    return {"id": seg_id, "status": "deleted"}


# =============================================================================
# RANK & SPLIT ENGINE
# =============================================================================


@router.post("/rank-split/preview")
async def rank_split_preview(payload: RankSplitRequest):
    """Preview per-group count, revenue, and avg spend for a rank/split config."""
    return await service.rank_split_preview(
        brand_code=payload.brand_code,
        rules=payload.rules,
        rank=[r.model_dump() for r in payload.rank],
        splits=[s.model_dump() for s in payload.splits],
        constraints=payload.constraints.model_dump() if payload.constraints else None,
    )


@router.post("/rank-split/save")
async def rank_split_save(payload: RankSplitSaveRequest):
    """Persist each rank/split group as a child segment in the repository."""
    return await service.save_rank_split_segments(
        brand_code=payload.brand_code,
        base_name=payload.base_name,
        rules=payload.rules,
        rank=[r.model_dump() for r in payload.rank],
        splits=[s.model_dump() for s in payload.splits],
        constraints=payload.constraints.model_dump() if payload.constraints else None,
        created_by=payload.created_by,
        parent_segment_id=payload.parent_segment_id,
    )


# =============================================================================
# AUDIENCE ESTIMATION & PREVIEW
# =============================================================================


@router.post("/estimate", response_model=AudienceEstimateResponse)
async def estimate_audience(payload: AudienceEstimateRequest):
    """
    Estimate audience size for a segment definition without saving it.
    Used by the segment builder UI for real-time count feedback.
    """
    result = await service.estimate_audience_size(
        brand_code=payload.brand_code,
        rules=payload.rules,
        datalake_config=payload.datalake_config,
        communication_group_view=payload.communication_group_view,
    )
    return result


@router.post("/summary", response_model=AudienceSummaryResponse)
async def get_segment_summary(payload: AudienceSummaryRequest):
    """
    Calculate behavioral summary metrics for a segment definition.
    Shown alongside audience size in the segment builder UI.
    """
    result = await service.get_segment_summary(
        brand_code=payload.brand_code,
        rules=payload.rules,
        metrics=payload.metrics,
        communication_group_view=payload.communication_group_view,
    )
    return result


@router.post("/preview", response_model=AudiencePreviewResponse)
async def preview_audience(payload: AudiencePreviewRequest):
    """
    Preview matching profiles for a segment definition.
    Returns sample rows to help users validate their segment logic.
    """
    result = await service.preview_audience(
        brand_code=payload.brand_code,
        rules=payload.rules,
        limit=payload.limit,
        datalake_config=payload.datalake_config,
        communication_group_view=payload.communication_group_view,
    )
    return result


# =============================================================================
# QUERY COMPILATION (for power users)
# =============================================================================


@router.post("/compile", response_model=CompileResponse)
async def compile_segment_query(payload: CompileRequest):
    """
    Compile segment rules into PostgreSQL SQL without executing.
    Useful for power users who want to review/modify the generated SQL.
    """
    sql = service.compile_segment_query(
        brand_code=payload.brand_code,
        rules=payload.rules,
        datalake_config=payload.datalake_config,
    )
    return CompileResponse(sql=sql, brand_code=payload.brand_code)


# =============================================================================
# SEGMENT COMPUTATION
# =============================================================================


@router.post("/{segment_id}/compute")
async def trigger_compute(segment_id: str):
    """Trigger manual computation of a segment's audience."""
    result = await service.compute_segment(segment_id)
    return result


# =============================================================================
# ATTRIBUTE CATALOG
# =============================================================================


@router.get("/attributes/{attribute_key:path}/values")
async def get_attribute_values(
    attribute_key: str,
    limit: int = Query(500, ge=1, le=2000, description="Max distinct values to return"),
    brand_code: str = Query("spencers", description="Brand to query values from"),
    search: str | None = Query(
        None,
        max_length=32,
        description=(
            "Optional prefix search for high-cardinality attributes (e.g. phone "
            "numbers). Non-digits are ignored. Requires at least "
            f"{PREFIX_SEARCH_MIN_DIGITS} digits; shorter input returns no values."
        ),
    ),
):
     # ── Prefix-search mode ────────────────────────────────────────────────
    if search is not None:
        digits = re.sub(r"\D", "", search)
 
        if len(digits) < PREFIX_SEARCH_MIN_DIGITS:
            return {
                "attribute_key": attribute_key,
                "values": [],
                "count": 0,
                "source": "database",
            }
 
        values = await service._search_attribute_values_async(
            attribute_key,
            prefix=digits,
            limit=min(limit, PREFIX_SEARCH_MAX_LIMIT),
            brand_code=brand_code,
        )
        return {
            "attribute_key": attribute_key,
            "values": values,
            "count": len(values),
            "source": "database",
        }
 
    # ── Existing behaviour (unchanged) ────────────────────────────────────
    values = await service._get_attribute_distinct_values_async(attribute_key, limit=limit, brand_code=brand_code)
    source = "database"
 
    # When the DB returns nothing (column empty, table missing, or brand not yet
    # populated) fall back to the catalog's static example_values so the UI
    # always has something useful to show rather than a blank dropdown.
    if not values:
        from app.schemas.profile_attributes import ATTRIBUTE_BY_KEY
        attr_def = ATTRIBUTE_BY_KEY.get(attribute_key)
        if attr_def and attr_def.example_values:
            values = [
                str(v)
                for v in attr_def.example_values
                if v is not None and str(v).strip()
            ]
            source = "catalog"
 
    return {
        "attribute_key": attribute_key,
        "values": values,
        "count": len(values),
        "source": source,
    }

@router.get("/attributes/catalog", response_model=AttributeCatalogResponse)
async def get_attribute_catalog(
    brand_code: str | None = Query(None, description="Filter attributes by brand"),
    category: str | None = Query(None, description="Filter by category"),
):
    """
    Get the full attribute catalog available for segmentation.
    This powers the segment builder UI's attribute picker.
    """
    attrs = ATTRIBUTE_CATALOG

    if brand_code:
        attrs = get_attributes_for_brand(brand_code)

    if category:
        try:
            cat = AttributeCategory(category)
            attrs = [a for a in attrs if a.category == cat]
        except ValueError:
            raise HTTPException(status_code=400, detail=f"Invalid category: {category}")

    categories = sorted(set(a.category.value for a in attrs))

    return AttributeCatalogResponse(
        attributes=[
            AttributeResponse(
                key=a.key,
                label=a.label,
                category=a.category.value,
                data_type=a.data_type.value,
                description=a.description,
                operators=a.operators,
                example_values=a.example_values,
                is_computed=a.is_computed,
                is_array=a.is_array,
                is_b2b_only=a.is_b2b_only,
                applicable_brands=a.applicable_brands,
                unit=a.unit,
                source_table=a.source_table,
            )
            for a in attrs
        ],
        total=len(attrs),
        categories=categories,
    )


# =============================================================================
# SEGMENT TEMPLATES
# =============================================================================

from app.services.segmentation.templates import (
    TEMPLATES,
    get_template_by_id,
    get_templates_by_category,
    get_templates_by_function,
    get_templates_for_brand,
)


@router.get("/templates/list")
async def list_templates(
    brand_code: str | None = Query(None, description="Filter templates by brand"),
    category: str | None = Query(None, description="Filter by category"),
    business_function: str | None = Query(None, description="Filter by business function (marketing, product, merch, cx, finance)"),
):
    """
    List available segment templates.
    Templates are pre-built segment definitions for common business use cases.
    """
    templates = TEMPLATES

    if brand_code:
        templates = get_templates_for_brand(brand_code)
    if category:
        templates = [t for t in templates if t.category == category]
    if business_function:
        templates = [t for t in templates if t.business_function == business_function]

    return {
        "templates": [t.to_dict() for t in templates],
        "total": len(templates),
    }


@router.get("/templates/{template_id}")
async def get_template(template_id: str):
    """Get a specific template by ID, ready to load into the segment builder."""
    template = get_template_by_id(template_id)
    if not template:
        raise HTTPException(status_code=404, detail="Template not found")
    return template.to_dict()


# =============================================================================
# NATURAL LANGUAGE SEGMENTATION
# =============================================================================

from functools import lru_cache

from app.services.nl_segmentation.service import NLSegmentationService


@lru_cache(maxsize=1)
def _get_nl_service() -> NLSegmentationService:
    return NLSegmentationService()


@router.post("/nl/query")
async def nl_segment_query(payload: dict):
    """
    Convert a natural language query into a segment definition, compile SQL,
    and return audience count.

    Example: "High spenders who haven't bought in 60 days in Kolkata"
    """
    nl_query = payload.get("query", "").strip()
    if not nl_query:
        raise HTTPException(status_code=400, detail="Query is required")

    brand_code = payload.get("brand_code", "spencers")
    execute = payload.get("execute", True)

    result = await _get_nl_service().query(
        nl_query=nl_query,
        brand_code=brand_code,
        execute=execute,
    )
    return result


@router.post("/nl/suggest")
async def nl_suggest(payload: dict):
    """Suggest query completions based on partial input."""
    partial = payload.get("query", "").strip()
    if not partial:
        return {"suggestions": []}

    suggestions = await _get_nl_service().suggest(partial)
    return {"suggestions": suggestions}


@router.post("/nl/explain")
async def nl_explain_rules(payload: dict):
    """Generate a human-readable explanation of a rule tree."""
    rules = payload.get("rules")
    if not rules:
        raise HTTPException(status_code=400, detail="Rules are required")

    explanation = await _get_nl_service().explain(rules)
    return {"explanation": explanation}
